import React from 'react';
import {Text,View,Image,StyleSheet, Button,TextInput,ScrollView} from 'react-native'
export default function Final(route){
    return(
        <View>
<Text style={{fontSize:40}}>Thanks for Booking </Text><Text style={{fontSize:40}}>Enjoy the show</Text>

        </View>
    )
}